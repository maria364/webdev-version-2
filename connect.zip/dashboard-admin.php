<?php include 'header.php'; ?>
    <!-- Header -->
    <header>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <img class="img-responsive" src="img/target.png" alt="">
                    <div class="intro-text">
                        <span class="name">SGip</span>
                        <hr class="star-light">
                        <span class="skills">Security Gun ip</span>
                    </div>
                </div>
            </div>
        </div>
    </header>
	
	
<?php include 'footer.php'; ?>

	
