<?php include 'header.php'; ?>

    <!-- Header -->
    <header>
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <h4>Πατώντας <i>Start</i> ξεκινάει το σύστημα (ενεργοποίηση όλου και αναγνώριση).</h4><br>
					<h4>Με το πάτημα του κουμπιού <i>Stop</i> όλο το σύστημα σταματά να ελέγχει το χώρο.</h4>
                    <div class="intro-text">
                        <ul >
							<li class="start">
								<h3><a href="exec.php" id="start" ><button type="button" class="btn btn-success" style="margin-right:90%">Start</button></a></h3>
							</li>
							<li class="delayed-start">
								<h3><a href="exec.php" id="start" ><button type="button" class="btn btn-success" style="margin-right:90%"> Delayed Start</button></a></h3>
							</li>
							<li class="stop">
								<h3><a href="streaming-admin.php"><button type="button" class="btn btn-success" style="margin-right:90%">Stop</button></a></h3>
							</li>
							<li class="delayed-stop">
								<h3><a href="streaming-admin.php"><button type="button" class="btn btn-success" style="margin-right:90%"> Delayed Stop</button></a></h3>
							</li>
						</ul>
                    </div>
                </div>
				
				<div class="col-lg-6">
					<div class="intro-text" >
								
					
					</div>
				</div>
			</div>
		<div>
	
    </header>
	
	<section>
			
	</section>
	
	
<?php include 'footer.php'; ?>